using namespace System.Web

Clear-Host

function PickList ($dataArray, $type) {
  $count = $dataArray.count
  Write-Host "Index`t $type"
  Write-Host "-----`t -----------------"
  for ($i = 0; $i -lt $count; $i++) {
    $index = $i + 1
    Write-Host "` " $index "`t" $dataArray[$i].name
  }
    
  do { [int]$choice = Read-host "`nEnter a valid $type index" } 
  until (($choice -gt 0) -and ($choice -le $count))
  
  $pick = $dataArray[$choice - 1]
  Write-Host -ForegroundColor Green "`nYou have selected: " -NoNewline; Write-Host -ForegroundColor White $pick
  return $pick
}

function checkLogin {
  $azContext = Get-AzContext
  if ($azContext -eq $null ) {
    Connect-AzAccount
  }
}

function getAllRepos {
  try {
    $response = Invoke-RestMethod 'https://api.github.com/user/repos?affiliation=owner' -Headers $headers -SkipHeaderValidation
    return $response
  }
  catch {
    Write-Host -ForegroundColor Red "Failed to get all repos from GitHub.  `nHere is the error I ran into: " 
    Write-Host $_
  }
} 

function generateRandomPassword {
  $length = 15

  $letters = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ".ToCharArray()
  $uppers = "ABCDEFGHJKLMNPQRSTUVWXYZ".ToCharArray()
  $lowers = "abcdefghijkmnopqrstuvwxyz".ToCharArray()
  $digits = "23456789".ToCharArray()
  $symbols = "_-+=@%".ToCharArray()

  $chars = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789_-+=@%".ToCharArray()

  do {
    $pwdChars = "".ToCharArray()
    $goodPassword = $false
    $hasDigit = $false
    $hasSymbol = $false
    $pwdChars += (Get-Random -InputObject $uppers -Count 1)
    for ($i = 1; $i -lt $length; $i++) {
      $char = Get-Random -InputObject $chars -Count 1
      if ($digits -contains $char) { $hasDigit = $true }
      if ($symbols -contains $char) { $hasSymbol = $true }
      $pwdChars += $char
    }
    $pwdChars += (Get-Random -InputObject $lowers -Count 1)
    $password = $pwdChars -join ""
    $goodPassword = $hasDigit -and $hasSymbol
  } until ($goodPassword)

  return $password
}

#######################################################################################################################
$location = "South Central US"
$github_secrets_file = "github_secrets.txt"
$tf_backend_config_file = "backend_config.hcl"
$tf_variable_file = "terraform.tfvars"

# Customer Name and Customer Increment
do { $CUSTOMER_NAME = Read-host "`nEnter customer name provided by Neverfail" } 
until (($CUSTOMER_NAME.Length -gt 0))

do {
  try {
    [int]$CUSTOMER_INCREMENT = Read-host "`nEnter customer increment provided by Neverfail (Default is 1)"
    if ($CUSTOMER_INCREMENT -eq 0) {
      Write-Host "Customer Increment set to default 1"
      $CUSTOMER_INCREMENT = 1;
    }
  }
  catch {
    Write-Host -ForegroundColor Red "Please retry with an integer value."
  }
}
until ($CUSTOMER_INCREMENT -gt 0)

# GitHub Token
$loginPassed = $false

do { 
  try {
    $GITHUB_TOKEN = Read-host "`nEnter a valid Github token"

    $headers = @{
      "Authorization" = "token ${GITHUB_TOKEN}"
      "Accept"        = "Accept: application/vnd.github.v3.raw"
    }
    
    $userInfo = Invoke-RestMethod 'https://api.github.com/user' -Headers $headers -SkipHeaderValidation
    if (!($userInfo.login)) {
      Write-Host -ForegroundColor Red "Error: Invalid Github token."
    }
    else {
      Write-Host -ForegroundColor Green "GitHub Token is valid."
      $loginPassed = $true
    }
  }
  catch {
    Write-Host -ForegroundColor Red "Something went wrong, seems the token isn't valid.  `nPlease re-check the token used."
  }
} 
until ($loginPassed)
  
# Checking for 'nfcc-azure-functions-deployment` repo
do {
  $allRepoResponse = getAllRepos
  $foundRepo = $false 

  Write-Host -ForegroundColor White "`nCollecting list of Repos from GitHub...."
   
  Foreach ($repo in $allRepoResponse) { 
    if ($repo.name.Contains('nfcc-azure-functions-deployment') -And !$repo.owner.login.Contains('neverfailcc')) {
      # Found rep 'nfcc-azure-functions-deployment' with owner not 'neverfailcc'
      $foundRepo = $true
    }
  }
   
  if (!$foundRepo) {
    Write-Host -ForegroundColor Red "`nSeems you don't have a repo named 'nfcc-azure-functions-deployment' in your list of repos. `nPlease follow 'nfcc-azure-functions-deployment-template' bot deployment instructions and create the repo 'nfcc-azure-functions-deployment'."
    Read-Host "`nHit 'enter' to continue"
  }
}
until ($foundRepo)

Write-Host -ForegroundColor Green  "Found 'nfcc-azure-functions-deployment' repo."

if (Test-Path $github_secrets_file) {
  Remove-Item $github_secrets_file
}
    
if (Test-Path $tf_backend_config_file) {
  Remove-Item $tf_backend_config_file
}
      
if (Test-Path $tf_variable_file) {
  Remove-Item $tf_variable_file
}
    
checkLogin

$randomPassword = generateRandomPassword
Write-Host -ForegroundColor Green "`nNOTE: Please copy your secure password, to access the private VMs created by the POC: " -NoNewline
Write-Host -ForegroundColor White $randomPassword
Read-Host "`nHit 'enter' to continue"

# Subscriptions
$azContext = Get-AzContext 
Write-Host -ForegroundColor White  "`nGetting a list of Subscriptions...."
$subscriptionArray = Get-AzSubscription
    
if ( $subscriptionArray.count -eq 0) {
  $option = Read-Host "`nHum, I can not find a subscription. Do you want me to create one (Y/N)?"
  if ( $option -eq 'Y' ) {
    Write-Host -ForegroundColor Green "Creating a new subscription..." 
    New-AzSubscription -Name "NFCC POC Subscription"  -DefaultProfile $azContext  -OfferType MS-AZR-0017
    Write-Host -ForegroundColor Green "New subscription create."
  } 
  else {
    Write-Host -ForegroundColor Red "`nSorry, I can not continue without a subscription."
    break
  }
}
else {
  Write-Host
  $subscription = PickList $subscriptionArray   "Subscription Name"
}
     
$azContext = Set-AzContext -SubscriptionId "$subscription"
    
# Resource Group
try {
  Write-Host -ForegroundColor White "`nProvisioning Resource Group for Terraform State File...."
  $resource_group = $CUSTOMER_NAME, "nf-tf-rg" , $CUSTOMER_INCREMENT -join "-"
  $resourceGroupExist = Get-AzResourceGroup -Name $resource_group -Location $location -DefaultProfile $azContext -ErrorAction Ignore
  if (!$resourceGroupExist) {
    $resourceGroup = New-AzResourceGroup -Name $resource_group -Location $location -Tag @{"NFCC-POC" = "true" } -DefaultProfile $azContext -Force
    Write-Host -ForegroundColor Green  "Resource group provisioned: " -NoNewline; Write-Host -ForegroundColor White $resource_group
  }
  else {
    Write-Host -ForegroundColor Green "Resource Group $resource_group already exist. Skipping creation."
  }
}
catch {
  Write-Host -ForegroundColor Red "Failed to create a Resource Group.  `nHere is the error I ran into: " 
  Write-Host $_
  Write-Host -ForegroundColor Red "Deleting Resource Group..."; Remove-AzResourceGroup -Name $resource_group -Force
  exit
}

# Storage Account
try {
  Write-Host -ForegroundColor White "`nProvisioning Storage Account for Terraform State File...."
  $storage_account_name = $CUSTOMER_NAME, "terraform", $CUSTOMER_INCREMENT -join ""
  $storageAccountExist = Get-AzStorageAccount -ResourceGroupName $resource_group -Name $storage_account_name -DefaultProfile $azContext -ErrorAction Ignore
  if (!$storageAccountExist) {
    $storageAccount = New-AzStorageAccount  -ResourceGroupName $resource_group -AccountName $storage_account_name -Location $location -SkuName Standard_LRS -Kind StorageV2 -Tag @{"NFCC-POC" = "true" } -DefaultProfile $azContext
    Write-Host -ForegroundColor Green  "Storage Account provisioned: " -NoNewline; Write-Host -ForegroundColor White $storage_account_name
  } 
  else {
    Write-Host -ForegroundColor Green "Storage Account $storage_account_name already exist. Skipping creation."
  }
}
catch {
  Write-Host -ForegroundColor Red "Failed to create a Storage Account.  `nHere is the error I ran into: " 
  Write-Host $_
  Write-Host -ForegroundColor Red "Deleting Storage Account..."; Remove-AzStorageAccount -ResourceGroupName $resource_group -Name $storage_account_name -Force
  exit
}

# Storage Container
try {
  Write-Host -ForegroundColor White "`nProvisioning Storage Container for Terraform State File...."
  $storageKey = (Get-AzStorageAccountKey -ResourceGroupName $resource_group -Name $storage_account_name).Value[0]
  $connectionString = "DefaultEndpointsProtocol=https;AccountName=$storage_account_name;AccountKey=$storageKey;EndpointSuffix=core.windows.net"
  $storageContext = New-AzStorageContext -StorageAccountName $storage_account_name -StorageAccountKey $storageKey
  $container_name = $CUSTOMER_NAME, "tfstate", $CUSTOMER_INCREMENT -join "-"
  $storageContainerExist = Get-AzStorageContainer -Name $container_name -Context $storageContext -ErrorAction Ignore
  if (!$storageContainerExist) {
    $storageContainer = New-AzStorageContainer -Name $container_name -Context $storageContext  -Permission Off
    Write-Host -ForegroundColor Green  "Storage Container provisioned: " -NoNewline; Write-Host -ForegroundColor White $container_name
  }
  else {
    Write-Host -ForegroundColor Green "Storage Container $container_name already exist. Skipping creation."
  }
}
catch {
  Write-Host -ForegroundColor Red "Failed to create a Storage Container.  `nHere is the error I ran into: " 
  Write-Host $_
  Write-Host -ForegroundColor Red "Deleting Storage Container..."; Remove-AzStorageContainer -Name $container_name -Force
  exit
}

# Create an Azure service principal 
try {
  Write-Host -ForegroundColor White "`nProvisioning App Registration...."
  $app_reg_name = $CUSTOMER_NAME, "nfcc" , $CUSTOMER_INCREMENT -join "-"
  $signed_in_user = az ad signed-in-user show --output json | ConvertFrom-Json 
  az account set --subscription $subscription 
  $servicePrincipal = az ad sp create-for-rbac --output json --name $app_reg_name --only-show-errors | ConvertFrom-Json 
  az ad app owner add --id $servicePrincipal.appId --owner-object-id $signed_in_user.objectId
  $azure_user_object_id = $signed_in_user.objectId
  Write-Host -ForegroundColor Green  "App registration completed." -NoNewline; Write-Output $servicePrincipal
}
catch {
  Write-Host -ForegroundColor Red "Failed to create App Registration.  `nHere is the error I ran into: " 
  Write-Host $_
}

Set-Content -Path $github_secrets_file -Value "# This file contains the variables needed to setup github secrets."
Add-Content -Path $github_secrets_file -Value 'AZURE_STORAGE_CONNECTION_STRING : '   -NoNewline; Add-Content -Path $github_secrets_file -Value `"$connectionString`" 
Add-Content -Path $github_secrets_file -Value 'AZURE_STORAGE_CONTAINER_NAME : '      -NoNewline; Add-Content -Path $github_secrets_file -Value $container_name
Add-Content -Path $github_secrets_file -Value 'ARM_ACCESS_KEY : '                    -NoNewline; Add-Content -Path $github_secrets_file -Value $storageKey 
Add-Content -Path $github_secrets_file -Value 'ARM_CLIENT_ID : '                     -NoNewline; Add-Content -Path $github_secrets_file -Value $servicePrincipal.appId
Add-Content -Path $github_secrets_file -Value 'ARM_CLIENT_SECRET : '                 -NoNewline; Add-Content -Path $github_secrets_file -Value $servicePrincipal.password
Add-Content -Path $github_secrets_file -Value 'ARM_SUBSCRIPTION_ID : '               -NoNewline; Add-Content -Path $github_secrets_file -Value $azContext.Subscription.SubscriptionId 
Add-Content -Path $github_secrets_file -Value 'ARM_TENANT_ID : '                     -NoNewline; Add-Content -Path $github_secrets_file -Value $servicePrincipal.tenant
Add-Content -Path $github_secrets_file -Value 'AZURE_DEFAULT_REGION : '              -NoNewline; Add-Content -Path $github_secrets_file -Value $location
Add-Content -Path $github_secrets_file -Value 'ADMIN_PASSWORD : '                    -NoNewline; Add-Content -Path $github_secrets_file -Value $randomPassword

Write-Host -ForegroundColor Green "GitHub secrets file create: " -NoNewline; Write-Host -ForegroundColor White $github_secrets_file
    
Set-Content -Path $tf_backend_config_file -Value "# backend_config.hcl"
Add-Content -Path $tf_backend_config_file -Value 'resource_group_name = '           -NoNewline; Add-Content -Path $tf_backend_config_file -Value `"$resource_group`"
Add-Content -Path $tf_backend_config_file -Value 'storage_account_name = '          -NoNewline; Add-Content -Path $tf_backend_config_file -Value `"$storage_account_name`"
Add-Content -Path $tf_backend_config_file -Value 'container_name = '                -NoNewline; Add-Content -Path $tf_backend_config_file -Value `"$container_name`"
Add-Content -Path $tf_backend_config_file -Value 'key = '                           -NoNewline; Add-Content -Path $tf_backend_config_file -Value `"poc_terraform.tfstate`"
Write-Host -ForegroundColor Green "Backend config file created: " -NoNewline; Write-Host -ForegroundColor White $tf_backend_config_file
    
Set-Content -Path $tf_variable_file -Value "# terraform variable file"
Add-Content -Path $tf_variable_file -Value 'azure_user_object_id = '                -NoNewline; Add-Content -Path $tf_variable_file -Value  `"$azure_user_object_id`"
Write-Host -ForegroundColor Green "Terraform variable file created: " -NoNewline; Write-Host -ForegroundColor White $tf_variable_file
     
$output = Set-AzStorageBlobContent -File $tf_backend_config_file -Container $container_name -Context $storageContext -Force
Write-Host -ForegroundColor Green "File uploaded to terraform state container: "  -NoNewline; Write-Host -ForegroundColor White $tf_backend_config_file
     
$output = Set-AzStorageBlobContent -File $tf_variable_file -Container $container_name -Context $storageContext -Force
Write-Host -ForegroundColor Green "File uploaded to terraform state container: "  -NoNewline; Write-Host -ForegroundColor White $tf_variable_file

try {
  $username = $userInfo.login
  $url = "https://api.github.com/repos/$username/azure-deployment/contents/utils/secrets.js"
  Write-Host "`nCreating the secrets with the required values on your repositories..."
  Invoke-WebRequest $url -Headers $headers -OutFile '.\secrets.js' -SkipHeaderValidation
  npm install  axios https tweetsodium > "/dev/null" 2>&1
  node secrets.js $GITHUB_TOKEN $storageKey $servicePrincipal.appId $servicePrincipal.password $azContext.Subscription.SubscriptionId $servicePrincipal.tenant $connectionString $container_name $CUSTOMER_NAME $CUSTOMER_INCREMENT $location $randomPassword
  Write-Host "Secrets have been created."
}
catch {
  Write-Host -ForegroundColor Red "Failed to upload Secrets in GitHub.  `nHere is the error I ran into: " 
  Write-Host $_
  exit
}